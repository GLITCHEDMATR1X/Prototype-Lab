HoloVerse drop-in: Indigo Giant cursor fix

Replace main.py in your HoloVerse folder with the one in this zip. Nothing else changes, and the
Indigo Giant project needs no edit.

Cause: entering a same-window dimension hides the mouse cursor (for first-person capture) unless the
dimension's manifest says otherwise. The Indigo Giant is mouse-driven (title menu buttons, click to go,
right-drag orbit), so its menu and mouse controls looked dead.

Fix: HoloVerse now keeps the cursor visible for The Indigo Giant (and for any dimension whose adapter
sets requires_mouse_capture = False). The cursor state is restored when you return.
